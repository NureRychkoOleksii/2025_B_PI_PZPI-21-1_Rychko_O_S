"use client";

import Link from "next/link";
import { useEffect } from "react";
import * as signalR from "@microsoft/signalr";
import { toast } from "sonner";
import { CheckCircle, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { isAuth } from "@/app/actions/auth";
export default function DonationSuccessPage() {

  useEffect(() => {
  let connection: signalR.HubConnection | null = null;

  async function setupConnection() {
    try {
      const token = await isAuth();
      if (!token) return;

      connection = new signalR.HubConnectionBuilder()
        .withUrl(`${process.env.NEXT_PUBLIC_API_BASE}/hubs/fundraising`, {
          accessTokenFactory: () => token,
          skipNegotiation: true,
          transport: signalR.HttpTransportType.WebSockets,
        })
        .withAutomaticReconnect()
        .build();

      connection.on("FundraisingGoalReached", (data) => {
        console.log("🎯 FundraisingGoalReached event received:", data);
        toast.success(`Ціль досягнута: ${data.title} — зібрано $${data.goal}`);
      });

      connection.onclose(error => {
        if (error) console.error("SignalR connection closed with error:", error);
        else console.log("SignalR connection closed");
      });

      connection.onreconnecting(error => {
        console.warn("SignalR reconnecting due to:", error);
      });

      connection.onreconnected(() => {
        console.log("SignalR reconnected");
      });

      await connection.start();
      console.log("✅ SignalR connection established on DonationSuccessPage");

     
    } catch (error) {
      console.error("Failed to establish SignalR connection:", error);
    }
  }

  setupConnection();

  return () => {
    if (connection) connection.stop();
  };
}, []);


  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">Дякуємо за ваш донат!</CardTitle>
        </CardHeader>

        <CardContent className="text-center space-y-6">
          <div className="space-y-2">
            <p className="text-gray-600">Ваш донат було успішно оброблено.</p>
            <p className="text-sm text-gray-500">Ви отримаєте підтвердження на електронну пошту найближчим часом.</p>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <p className="text-sm text-green-800">
              Ваша підтримка допомагає нам досягати наших цілей. Дякуємо за довіру та участь у наших ініціативах!
            </p>
          </div>

          <div className="space-y-3">
            <Button asChild className="w-full">
              <Link href="/">
                <Home className="mr-2 h-4 w-4" />
                Повернутися на головну
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
