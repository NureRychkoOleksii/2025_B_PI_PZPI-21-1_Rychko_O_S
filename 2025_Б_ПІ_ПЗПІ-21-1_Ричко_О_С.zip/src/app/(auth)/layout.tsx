import { Header } from "@/components/header";


export default function AuthLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {

    return (
        <div className="min-h-screen flex flex-col container mx-auto">
            <Header isAuthPage={true} />
            {children}
        </div>
    );
}
