"use server"

import { cookies } from "next/headers"
import * as signalR from "@microsoft/signalr";

type Initiative = {
  id?: number;
  imageBase64: string;
  title: string;
  description: string;
};


let connection: signalR.HubConnection;


export async function getAllInitiatives() {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/byCategories`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      }
    })


    if (!initiatives.ok) {
      throw new Error("Failed to fetch initiatives:")
    }

    const response = await initiatives.json()

    return response

  } catch (error) {
    console.error("Error fetching initiatives:", error)
    return []
  }
}


export async function getInitiativeById(id: number) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/GetInitiativeById?id=${id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      }
    })


    if (!initiatives.ok) {
      throw new Error("Failed to fetch initiative:")
    }

    const response = await initiatives.json()

    return response

  } catch (error) {
    console.error("Error fetching initiative:", error)
    return []
  }
}


export async function deleteInitiative(id: number) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/InitiativeDelete?id=${id}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      }
    })


    if (!initiatives.ok) {
      throw new Error("Failed to delete initiative:")
    }

    const response = await initiatives.json()

    return response

  } catch (error) {
    console.error("Error delete initiative:", error)
    return []
  }
}


export async function createInitiative(initiative: FormData) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/AddInitiative`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
      },
      body: initiative,
    });

    if (!initiatives.ok) {
      throw new Error("Failed to create initiative:");
    }

    const response = await initiatives.json();
    return response;

  } catch (error) {
    console.error("Error create initiative:", error);
    return [];
  }
}

export async function editInitiative(id: number, formData: FormData) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/EditInitiative?id=${id}`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      }
    );

    if (!response.ok) {
      throw new Error("Failed to update initiative");
    }

    return await response.json();
  } catch (error) {
    console.error("Error updating initiative:", error);
    return [];
  }
}




export async function getInitiativeByCategories(page: number, categoryNames: string[]) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const categoryParams = categoryNames.map((name) => `categoryNames=${encodeURIComponent(name)}`).join("&")

    const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/byCategoriesWithPagin?${categoryParams}&page=${page}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      }
    })
    console.log('int', initiatives)

    if (!initiatives.ok) {
      throw new Error("Failed to fetch initiative:")
    }

    const response = await initiatives.json()

    return response

  } catch (error) {
    console.error("Error fetching initiative:", error)
    return []
  }
}

export async function getInitiativeStatistic(id: number) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/InitiativeStat?id=${id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      }
    })


    if (!initiatives.ok) {
      throw new Error("Failed to fetch initiative:")
    }

    const response = await initiatives.json()

    return response

  } catch (error) {
    console.error("Error fetching initiative:", error)
    return []
  }
}
/*
export async function subscribeToInitiative(initiativeId: number) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Subscribe`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json-patch+json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({ initiativeId }),
    })

    if (!response.ok) {
      throw new Error("Failed to subscribe to initiative")
    }

    if (!connection) {
      connection = new signalR.HubConnectionBuilder()
        .withUrl(`${process.env.NEXT_PUBLIC_API_BASE}/hubs/fundraising`, {
          accessTokenFactory: () => token || "",
          skipNegotiation: true,
          transport: signalR.HttpTransportType.WebSockets
        })
        .withAutomaticReconnect()
        .build();

      await connection.start();
    }
     connection.on('NewFundraisingCreated', data => {
      console.log('🚀 NewFundraisingCreated:', data);
    });

    await connection.invoke("SubscribeToInitiative", initiativeId);
    console.log(`✅ Subscribed to initiative ${initiativeId} via SignalR`);
   

    return await response.json()
  } catch (error) {
    console.error("Subscription error:", error);
    return null;
  }
}

*/




/* export async function unsubscribeFromInitiative(id: number | null) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Subscribe/UnsubscribeFromInitiative?id=${id}`, {
      method: "DELETE",
      headers: {
        "Authorization": `Bearer ${token}`,
      }
    })

    console.log(response, "delete ")

    if (!response.ok) {
      throw new Error("Failed to unsubscribe from initiative")
    }

    if (response.status === 204) {
      return null;
    }

    return await response.json()
  } catch (error) {
    console.error("Error unsubscribing from initiative:", error)
    return null
  }
} */





export async function getMySubscriptions() {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Subscribe/MySubscribe`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/json",
      },
      cache: "no-store",
    })

    if (!response.ok) {
      throw new Error("Failed to fetch user subscriptions")
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching subscriptions:", error)
    return []
  }
}



export async function changeInitiativeCategory(initiativeId: number, newCategoryId: number): Promise<boolean> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/admin/ChangeInitiativeCategory?initiativeId=${initiativeId}&newCategoryId=${newCategoryId}`,
      {
        method: "PUT",
        headers: {
          "Accept": "*/*",
          "Authorization": `Bearer ${token}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error("Failed to change initiative category");
    }

    return true;
  } catch (error) {
    console.error("Error changing initiative category:", error);
    return false;
  }
}


export async function approveInitiative(id: number, isApproved: boolean): Promise<boolean> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/admin/approval?id=${id}&isApproved=${isApproved}`,
      {
        method: "PUT",
        headers: {
          "accept": "*/*",
          "Authorization": `Bearer ${token}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error("Failed to approve initiative");
    }

    return true;
  } catch (error) {
    console.error("Error approving initiative:", error);
    return false;
  }
}


export async function getUserInitiatives() {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Initiative/GetUserInitiatives`, {
      method: "GET",
      headers: {
        "Accept": "*/*",
        "Authorization": `Bearer ${token}`,
      }
    })

    if (!res.ok) {
      throw new Error("Failed to fetch user initiatives")
    }

    const data = await res.json()
    return data

  } catch (error) {
    console.error("Error fetching user initiatives:", error)
    return []
  }
}