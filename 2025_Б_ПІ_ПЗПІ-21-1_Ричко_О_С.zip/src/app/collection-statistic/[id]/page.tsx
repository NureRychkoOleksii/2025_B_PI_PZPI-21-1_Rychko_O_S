"use client"

import { useState, useEffect, startTransition } from "react"
import { useParams } from "next/navigation"
import { ChevronLeft, Target, Calendar, BarChart2, Award } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, type TooltipProps } from "recharts"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { getCollectionStatistics } from "@/app/actions/collections"
import { getAllTopDonors } from "@/app/actions/donation"
import { Loader } from "@/components/loader"

const collectionsMockData = [
  {
    id: "collection-1",
    name: "Допомога військовим",
    goal: 20000,
    collected: 15000,
    deadline: "2025-06-15",
    dailyStats: [
      { date: "2025-05-01", amount: 1200 },
      { date: "2025-05-02", amount: 800 },
      { date: "2025-05-03", amount: 1500 },
      { date: "2025-05-04", amount: 2000 },
      { date: "2025-05-05", amount: 1800 },
      { date: "2025-05-06", amount: 2200 },
      { date: "2025-05-07", amount: 1700 },
      { date: "2025-05-08", amount: 1900 },
      { date: "2025-05-09", amount: 1800 },
      { date: "2025-05-10", amount: 2000 },
    ],
    topDonors: [
      { id: "user-1", name: "Олександр Петренко", amount: 3000, avatar: "/spongebob-1.jpg" },
      { id: "user-2", name: "Марія Ковальчук", amount: 2500, avatar: "/spongebob-2.jpg" },
      { id: "user-3", name: "Іван Мельник", amount: 2000, avatar: "/spongebob-3.jpg" },
      { id: "user-4", name: "Наталія Шевченко", amount: 1800, avatar: "/spongebob-4.jpg" },
      { id: "user-5", name: "Сергій Бондаренко", amount: 1500, avatar: "/spongebob-5.jpg" },
    ],
  },
  {
    id: "collection-2",
    name: "Медичне обладнання",
    goal: 50000,
    collected: 32000,
    deadline: "2025-07-20",
    dailyStats: [
      { date: "2025-05-01", amount: 3000 },
      { date: "2025-05-02", amount: 2500 },
      { date: "2025-05-03", amount: 4000 },
      { date: "2025-05-04", amount: 3500 },
      { date: "2025-05-05", amount: 5000 },
      { date: "2025-05-06", amount: 4500 },
      { date: "2025-05-07", amount: 3800 },
      { date: "2025-05-08", amount: 4200 },
      { date: "2025-05-09", amount: 3000 },
      { date: "2025-05-10", amount: 2500 },
    ],
    topDonors: [
      { id: "user-6", name: "Олена Коваленко", amount: 5000, avatar: "/spongebob-1.jpg" },
      { id: "user-7", name: "Андрій Лисенко", amount: 4500, avatar: "/spongebob-2.jpg" },
      { id: "user-8", name: "Тетяна Мороз", amount: 4000, avatar: "/spongebob-3.jpg" },
      { id: "user-9", name: "Василь Ткаченко", amount: 3500, avatar: "/spongebob-4.jpg" },
      { id: "user-10", name: "Юлія Савченко", amount: 3000, avatar: "/spongebob-5.jpg" },
    ],
  },
  {
    id: "collection-3",
    name: "Підтримка дітей",
    goal: 15000,
    collected: 9000,
    deadline: "2025-08-10",
    dailyStats: [
      { date: "2025-05-01", amount: 800 },
      { date: "2025-05-02", amount: 600 },
      { date: "2025-05-03", amount: 1200 },
      { date: "2025-05-04", amount: 900 },
      { date: "2025-05-05", amount: 1500 },
      { date: "2025-05-06", amount: 1100 },
      { date: "2025-05-07", amount: 1000 },
      { date: "2025-05-08", amount: 800 },
      { date: "2025-05-09", amount: 700 },
      { date: "2025-05-10", amount: 1400 },
    ],
    topDonors: [
      { id: "user-11", name: "Дмитро Іванченко", amount: 2000, avatar: "/spongebob-1.jpg" },
      { id: "user-12", name: "Ірина Павленко", amount: 1800, avatar: "/spongebob-2.jpg" },
      { id: "user-13", name: "Максим Кравчук", amount: 1500, avatar: "/spongebob-3.jpg" },
      { id: "user-14", name: "Оксана Литвин", amount: 1200, avatar: "/spongebob-4.jpg" },
      { id: "user-15", name: "Роман Білоус", amount: 1000, avatar: "/spongebob-5.jpg" },
    ],
  },
]

interface DailyIncome {
  date: string
  amount: number
}

interface CollectionStatistics {
  fundraisingId: number
  goal: number
  totalCollected: number
  updatedAt: string
  dailyIncomes: DailyIncome[]
}

interface TopDonor {
  userId: number
  normalizedName: string
  avatarBase64: string | null
  totalAmount: number
}

const CustomTooltip = ({ active, payload }: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload
    return (
      <div className="bg-white border border-gray-200 rounded-md shadow-md p-2">
        <p className="text-sm text-gray-600">
          {new Date(data.rawDate).toLocaleDateString("uk-UA", {
            day: "numeric",
            month: "long",
            year: "numeric",
          })}
        </p>
        <p className="font-medium">{data.amount.toLocaleString()} ₴</p>
      </div>
    )
  }
  return null
}

export default function CollectionStatisticPage() {
  const params = useParams()
  const [collection, setCollection] = useState<CollectionStatistics | null>(null)
  const [topDonors, setTopDonors] = useState<TopDonor[]>([])
  const [cumulativeData, setCumulativeData] = useState<{ date: string; amount: number; rawDate: string }[]>([])

  useEffect(() => {
    startTransition(async () => {
      const statistics = await getCollectionStatistics(Number(params.id))
      const donaters = await getAllTopDonors(Number(params.id))

      setCollection(statistics)
      setTopDonors(donaters)

      let cumulativeAmount = 0
      const cumulativeStats = statistics.dailyIncomes.map((income: DailyIncome) => {
        cumulativeAmount += income.amount
        return {
          date: new Date(income.date).toLocaleDateString("uk-UA", { day: "numeric", month: "short" }),
          amount: cumulativeAmount,
          rawDate: income.date,
        }
      })
      setCumulativeData(cumulativeStats)
    })
  }, [params.id])

  const getMedalColor = (place: number) => {
    switch (place) {
      case 1:
        return "text-yellow-500"
      case 2:
        return "text-gray-400"
      case 3:
        return "text-amber-700"
      default:
        return "text-gray-500"
    }
  }

  if (!collection) {
    return (
      <div className="flex justify-center items-center h-screen">
           <Loader />
      </div>
    )
  }

  const progressPercent = Math.min(100, (collection.totalCollected / collection.goal) * 100)

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="mb-6">
        <Button variant="ghost" className="flex items-center gap-2 pl-0 hover:bg-transparent" asChild>
          <Link href="/user-profile" className="text-gray-600 hover:text-gray-900">
            <ChevronLeft size={20} />
            <span>Назад до Мої збори</span>
          </Link>
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h1 className="text-2xl font-semibold mb-4">Статистика збору</h1>

        <div className="mb-6">
          <h2 className="text-xl font-medium mb-2">Збір №{collection.fundraisingId}</h2>

          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-gray-500" />
              <span className="text-gray-700">
                Ціль: <span className="font-medium">{collection.goal.toLocaleString()} ₴</span>
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-gray-500" />
              <span className="text-gray-700">
                Оновлено:{" "}
                <span className="font-medium">
                  {new Date(collection.updatedAt).toLocaleDateString("uk-UA", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
              </span>
            </div>
          </div>

          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
            <div className="bg-green-600 h-2.5 rounded-full" style={{ width: `${progressPercent}%` }}></div>
          </div>

          <div className="flex justify-between text-sm mb-4">
            <span className="text-gray-600">Зібрано: {collection.totalCollected.toLocaleString()} ₴</span>
            <span className="text-gray-600">{Math.round(progressPercent)}%</span>
          </div>
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
            <BarChart2 size={20} className="text-gray-600" />
            Динаміка збору коштів
          </h3>

          <div className="mt-8 h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={cumulativeData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis tickFormatter={(value) => `${value.toLocaleString()} ₴`} width={80} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="amount"
                  stroke="#16a34a"
                  strokeWidth={2}
                  dot={{
                    r: 4,
                    fill: "#16a34a",
                    strokeWidth: 2,
                    stroke: "#fff",
                  }}
                  activeDot={{
                    r: 6,
                    fill: "#16a34a",
                    strokeWidth: 2,
                    stroke: "#fff",
                  }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-10 pt-6 border-t">
            <h3 className="text-lg font-medium mb-4">Топ донатери</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {topDonors.map((donor, index) => (
                <div key={donor.userId} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg relative">
                  <div
                    className={`absolute -top-2 -left-2 flex items-center justify-center w-8 h-8 rounded-full bg-white shadow-sm ${getMedalColor(index + 1)}`}
                  >
                    <Award size={16} className={getMedalColor(index + 1)} />
                    <span className="text-xs font-bold">{index + 1}</span>
                  </div>
                  <Avatar className="h-10 w-10 ml-4">
                    <AvatarImage
                      src={donor.avatarBase64 || "/placeholder.svg"}
                      alt={donor.normalizedName}
                    />
                    <AvatarFallback className="bg-gray-200 text-gray-700">
                      {donor.normalizedName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{donor.normalizedName}</p>
                      <span className="ml-2 text-sm text-gray-600">Місце №{index + 1}</span>
                    </div>
                    <p className="text-sm text-gray-600">{donor.totalAmount.toLocaleString()} ₴</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
