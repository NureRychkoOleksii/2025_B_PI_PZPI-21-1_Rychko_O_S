"use client"

import type React from "react"

import { getInitiativeById, getMySubscriptions } from "@/app/actions/initiatives"
import { CollectionCard } from "@/components/collection-card"
import { InputSearch } from "@/components/input-search"
import { Loader } from "@/components/loader"
import { ShareModal } from "@/components/share-modal"
import { SubscribeDialog } from "@/components/subscribe-dialog"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { format } from "date-fns"
import { AlertCircle, ArrowLeft, CalendarIcon, CheckCircle, PlusCircle, Share2 } from "lucide-react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { startTransition, useEffect, useRef, useState } from "react"
import { createCollection, getAllCollectionByInitiativeId } from "@/app/actions/collections"
import { isAuth } from "@/app/actions/auth"
import { createCheckoutSession, subscribeToInitiative } from "@/hooks/gavno"




type Initiative = {
    id: number
    title: string
    description: string
    imageBase64: string
    categoryId: number
    userId: number
    fundraisings: any[]
    category?: any | null
    stat?: any | null
    subscribes?: any | null
    user?: any | null
    isApproved: boolean;
}

type FundraisingForm = {
    title: string
    goalAmount: string
    deadline: Date | undefined
}

export default function InitiativeDetailPage() {
    const params = useParams()
    const router = useRouter()
    const id = Number(params.id)
    const [initiative, setInitiative] = useState<Initiative | null>(null)
    const [isSubscribed, setIsSubscribed] = useState(false)
    const [showShareModal, setShowShareModal] = useState(false)
    const [showSubscribeDialog, setShowSubscribeDialog] = useState(false)
    const [showCreateFundraisingModal, setShowCreateFundraisingModal] = useState(false)
    const [searchQuery, setSearchQuery] = useState("")
    const shareUrl = typeof window !== "undefined" ? window.location.href : ""
    const [isAuthenticated, setIsAuthenticated] = useState(false)
    const [fundraisingData, setFundraisingData] = useState<any[]>([])
    const [showDonationModal, setShowDonationModal] = useState(false)
    const [donationAmount, setDonationAmount] = useState("")
    const [selectedFundraisingId, setSelectedFundraisingId] = useState<number | null>(null)
    const [mySubscription, setMySubscription] = useState([])
    const [cards, setCards] = useState<any[]>([])

    const [jwtToken, setJwtToken] = useState<string | null>(null)

        useEffect(() => {
        startTransition(async () => {
            const tokenAuth = await isAuth()
            if(tokenAuth) {
                setJwtToken(tokenAuth)
            }
        })
        
        }, [])



    const [fundraisingForm, setFundraisingForm] = useState<FundraisingForm>({
        title: "",
        goalAmount: "",
        deadline: undefined,
    })
    const [datePickerOpen, setDatePickerOpen] = useState(false)

    useEffect(() => {
        fetch("/api/user-info")
            .then((res) => res.ok && setIsAuthenticated(true))
            .catch(() => setIsAuthenticated(false))
    }, [])

    useEffect(() => {
        startTransition(async () => {
            const initiative = await getInitiativeById(id)
            const fundraisingData = await getAllCollectionByInitiativeId(id)
            const subscription = await getMySubscriptions()
            setMySubscription(subscription)
            const cardData = subscription.map((sub: any) => ({
                id: sub.id,
                initiativeId: sub.initiativeId,
                title: sub.initiative?.title || "Без назви",
                description: sub.initiative?.description || "",
                image: sub.initiative?.imageBase64 || "/placeholder.jpg",
            }))
            setCards(cardData)
            setInitiative(initiative)
            setFundraisingData(fundraisingData)

        })
    }, [id, router])




    

    console.log("cards", cards)

    const handleSubscribeClick = async () => {
        if (!isSubscribed) {
            const response = await subscribeToInitiative(id)
            console.log(response, "res")
            const subscription = await getMySubscriptions()
            setMySubscription(subscription)
            const cardData = subscription.map((sub: any) => ({
                id: sub.id,
                initiativeId: sub.initiativeId,
                title: sub.initiative?.title || "Без назви",
                description: sub.initiative?.description || "",
                image: sub.initiative?.imageBase64 || "/placeholder.jpg",
            }))
            setCards(cardData)
            setShowSubscribeDialog(true)
        }
    }

    const handleCreateFundraisingClick = () => {
        setShowCreateFundraisingModal(true)
    }

    const handleSubscribeConfirm = () => {
        setIsSubscribed(!isSubscribed)
        setShowSubscribeDialog(false)
    }

    const handleDonationModelOpen = (id: number) => {
        setSelectedFundraisingId(id)
        setShowDonationModal(true)
    }


    const handleDonationConfirm = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!selectedFundraisingId) return;

        const stripeSession = {
            fundraisingId: selectedFundraisingId,
            amount: Number(donationAmount),
            successUrl: `${window.location.origin}/donation-success`,
            cancelUrl: `${window.location.origin}/donation-cancel`,
        };

        const response = await createCheckoutSession(stripeSession)

        console.log(response, "stripe session response");

        if (response?.sessionId?.item2) {
            window.location.href = response.sessionId.item2;
        } else {
            console.error("Stripe session URL not found in response");
        }

        setDonationAmount("");
        setShowDonationModal(false);
        setSelectedFundraisingId(null);
    };


    const handleCreateFundraisingSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        const formattedDeadline = fundraisingForm.deadline?.toISOString()

        const fundraisingData = {
            title: fundraisingForm.title,
            goalAmount: Number(fundraisingForm.goalAmount),
            deadline: formattedDeadline,
            initiativeId: id,
        }

        await createCollection(fundraisingData)
        const updatedFundraisings = await getAllCollectionByInitiativeId(id)
        setFundraisingData(updatedFundraisings)

        setFundraisingForm({
            title: "",
            goalAmount: "",
            deadline: undefined,
        })
        setShowCreateFundraisingModal(false)
        setDatePickerOpen(false)
    }

    const filteredFundraisings = fundraisingData.filter((item) =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()),
    )

    if (!initiative) {
        return (
            <div className="flex items-center justify-center min-h-[60vh]">
                <Loader />
            </div>
        )
    }

    console.log(fundraisingData, "fundraisingData")
    console.log(initiative, "init")

    return (
        <div className="container mx-auto py-8 px-4">
            <Link href="/" className="flex items-center text-gray-600 hover:text-gray-900 mb-6">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Назад до списку ініціатив
            </Link>

            <div className="bg-white rounded-lg shadow-md overflow-hidden max-w-4xl mx-auto">
                <div className="relative w-full h-[300px] sm:h-[400px]">
                    <img
                        src={`data:image/jpeg;base64,${initiative.imageBase64}` || "/placeholder.svg"}
                        alt={initiative.title}
                        className="w-full h-full object-cover"
                    />
                </div>

                <div className="p-6">
                    <h1 className="text-2xl font-bold text-gray-800 mb-4">{initiative.title}</h1>
                    <p className="text-gray-600 mb-6">{initiative.description}</p>

                    <div className="flex flex-wrap gap-3">
                        {isAuthenticated && (
                            <Button onClick={handleSubscribeClick} variant={isSubscribed ? "outline" : "default"}>
                                {isSubscribed ? "Відписатися" : "Підписатися"}
                            </Button>
                        )}
                        <Button variant="outline" onClick={() => setShowShareModal(true)}>
                            <Share2 className="mr-2 h-4 w-4" />
                            Поділитися
                        </Button>
                        <Button variant="outline" asChild>
                            <Link href={`/initiative-statistic/${id}`}>Статистика</Link>
                        </Button>
                        {isAuthenticated && initiative?.isApproved && (
                            <Button className="cursor-pointer" variant="outline" onClick={handleCreateFundraisingClick}>
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Створити збір
                            </Button>
                        )}
                            {initiative.isApproved ? (
                                <span className="flex items-center text-green-600 text-sm">
                                    <CheckCircle className="w-4 h-4 mr-1" />
                                    Підтверджено
                                </span>
                            ) : (
                                <span className="flex items-center text-yellow-600 text-sm">
                                    <AlertCircle className="w-4 h-4 mr-1" />
                                    Не підтверджено
                                </span>
                            )}
                    </div>
                </div>
            </div>

            <div className="mt-10 max-w-4xl mx-auto">
                <h2 className="text-xl font-bold text-gray-800 mb-4">Fundraising</h2>
                <div className="mb-4">
                    <InputSearch placeholder="Пошук зборів" searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredFundraisings.length > 0 ? (
                        filteredFundraisings.map((item) => (
                            <CollectionCard
                                key={item.id}
                                id={item.id}
                                title={item.title}
                                goal={item.goalAmount}
                                collected={item.totalCollected || 0}
                                deadline={item.deadline}
                                isBlocked={item.isBlocked}
                                description={item.description}
                                isAuthenticated={isAuthenticated}
                                handleDonationModelOpen={() => handleDonationModelOpen(item.id)}
                                showDonationModal={showDonationModal}
                                donationAmount={donationAmount}
                                setDonationAmount={setDonationAmount}
                                setShowDonationModal={setShowDonationModal}
                                handleDonationConfirm={handleDonationConfirm}
                            />
                        ))
                    ) : (
                        <div className="col-span-2 text-center py-8 text-gray-500">Не знайдено зборів за вашим запитом</div>
                    )}
                </div>
            </div>
            <FundraisingDialog open={showCreateFundraisingModal} onOpenChange={setShowCreateFundraisingModal}>
                <DialogHeader>
                    <DialogTitle>Створити новий збір</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateFundraisingSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Назва збору</Label>
                        <Input
                            id="title"
                            placeholder="Назва збору"
                            value={fundraisingForm.title}
                            onChange={(e) =>
                                setFundraisingForm((prev) => ({
                                    ...prev,
                                    title: e.target.value,
                                }))
                            }
                            required
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="goalAmount">Ціль</Label>
                        <Input
                            id="goalAmount"
                            type="number"
                            placeholder="Ціль"
                            value={fundraisingForm.goalAmount}
                            onChange={(e) =>
                                setFundraisingForm((prev) => ({
                                    ...prev,
                                    goalAmount: e.target.value,
                                }))
                            }
                            required
                            min="1"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label>Дедлайн</Label>
                        <div className="border rounded-md p-3">
                            {fundraisingForm.deadline && (
                                <div className="mb-2 text-sm">Обрана дата: {format(fundraisingForm.deadline, "dd.MM.yyyy")}</div>
                            )}
                            <Calendar
                                mode="single"
                                selected={fundraisingForm.deadline}
                                onSelect={(date) => {
                                    if (date) {
                                        setFundraisingForm((prev) => ({
                                            ...prev,
                                            deadline: date,
                                        }))
                                    }
                                }}
                                disabled={(date) => date < new Date() || date < new Date("1900-01-01")}
                                className="w-full rounded-md border"
                            />
                        </div>
                    </div>

                    <div className="flex justify-end space-x-2 pt-4">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                                setShowCreateFundraisingModal(false)
                            }}
                        >
                            Скасувати
                        </Button>
                        <Button type="submit">Створити збір</Button>
                    </div>
                </form>
            </FundraisingDialog>

            <ShareModal open={showShareModal} onOpenChange={setShowShareModal} url={shareUrl} />
            <SubscribeDialog
                open={showSubscribeDialog}
                onOpenChange={setShowSubscribeDialog}
                isSubscribed={isSubscribed}
                onConfirm={handleSubscribeConfirm}
            />
        </div>
    )
}



function FundraisingDialog({
    open,
    onOpenChange,
    children,
}: {
    open: boolean
    onOpenChange: (open: boolean) => void
    children: React.ReactNode
}) {
    const dialogRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
        const handleClick = (e: MouseEvent) => {
            if (dialogRef.current && dialogRef.current.contains(e.target as Node)) {
                e.stopPropagation()
            }
        }

        if (open) {
            document.addEventListener("mousedown", handleClick)
        }

        return () => {
            document.removeEventListener("mousedown", handleClick)
        }
    }, [open])

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent ref={dialogRef}>{children}</DialogContent>
        </Dialog>
    )
}

