"use client";

import {
  ChevronLeft,
  BarChart2,
  TrendingUp,
  ArrowUp,
  ArrowDown,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  type TooltipProps,
} from "recharts";
import { ResponsiveContainer } from "recharts";
import { Card, CardContent } from "@/components/ui/card";
import { useParams } from "next/navigation";
import { startTransition, useEffect, useState } from "react";
import { getInitiativeStatistic } from "@/app/actions/initiatives";

type InitiativeStatistic = {
  date: string;
  totalAmount: number;
};

const CustomTooltip = ({ active, payload }: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white border border-gray-200 rounded-md shadow-md p-2">
        <p className="text-sm text-gray-600">
          {new Date(data.rawDate).toLocaleDateString("uk-UA", {
            day: "numeric",
            month: "long",
            year: "numeric",
          })}
        </p>
        <p className="font-medium">${data.amount.toLocaleString()}</p>
      </div>
    );
  }
  return null;
};

export default function InitiativeStatisticPage() {
  const [initiativeStatistic, setInitiativeStatistic] = useState<
    InitiativeStatistic[]
  >([]);

  const params = useParams();
  useEffect(() => {
    startTransition(async () => {
      const response = await getInitiativeStatistic(Number(params.id));
      setInitiativeStatistic(response);
    });
  }, [params.id]);

  console.log("initiativeStatistic", initiativeStatistic);

  let cumulativeAmount = 0;
  const chartData = initiativeStatistic.map((item) => {
    cumulativeAmount += item?.totalAmount;

    return {
      date: new Date(item.date).toLocaleDateString("uk-UA", {
        day: "numeric",
        month: "short",
      }),
      amount: cumulativeAmount,
      rawDate: item.date,
    };
  });

  const currentAmount =
    initiativeStatistic[initiativeStatistic.length - 1]?.totalAmount || 0;
  const previousAmount =
    initiativeStatistic[initiativeStatistic.length - 2]?.totalAmount || 0;
  const totalAmount = initiativeStatistic.reduce(
    (sum, item) => sum + item.totalAmount,
    0
  );
  const averageAmount = totalAmount / initiativeStatistic.length;

  const changeAmount = currentAmount - previousAmount;
  const changePercent = ((changeAmount / previousAmount) * 100).toFixed(1);
  const isPositiveChange = changeAmount >= 0;

  const highestMonth =
    initiativeStatistic.length > 0
      ? [...initiativeStatistic].sort(
          (a, b) => b.totalAmount - a.totalAmount
        )[0]
      : null;

  const lowestMonth =
    initiativeStatistic.length > 0
      ? [...initiativeStatistic].sort(
          (a, b) => a.totalAmount - b.totalAmount
        )[0]
      : null;

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="mb-6">
        <Button
          variant="ghost"
          className="flex items-center gap-2 pl-0 hover:bg-transparent"
          asChild
        >
          <Link href="/" className="text-gray-600 hover:text-gray-900">
            <ChevronLeft size={20} />
            <span>Назад до панелі</span>
          </Link>
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h1 className="text-2xl font-semibold mb-4">Статистика ініціативи</h1>

        <div className="mb-6">
          <h2 className="text-xl font-medium mb-4">Ключові показники</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <span className="text-sm text-gray-500 mb-1">
                    Поточний місяць
                  </span>
                  <span className="text-2xl font-bold">
                    ${currentAmount.toLocaleString()}
                  </span>
                  <div className="flex items-center mt-2">
                    {isPositiveChange ? (
                      <ArrowUp className="h-4 w-4 text-green-500 mr-1" />
                    ) : (
                      <ArrowDown className="h-4 w-4 text-red-500 mr-1" />
                    )}
                    <span
                      className={`text-sm ${
                        isPositiveChange ? "text-green-500" : "text-red-500"
                      }`}
                    >
                      {isPositiveChange ? "+" : ""}
                      {changePercent}% від попереднього
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <span className="text-sm text-gray-500 mb-1">
                    Загальна сума
                  </span>
                  <span className="text-2xl font-bold">
                    ${totalAmount.toLocaleString()}
                  </span>
                  <span className="text-sm text-gray-500 mt-2">
                    За весь період
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <span className="text-sm text-gray-500 mb-1">
                    Середня сума
                  </span>
                  <span className="text-2xl font-bold">
                    ${Math.round(averageAmount).toLocaleString()}
                  </span>
                  <span className="text-sm text-gray-500 mt-2">За місяць</span>
                </div>
              </CardContent>
            </Card>

            {/*  <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <span className="text-sm text-gray-500 mb-1">Найкращий місяць</span>
                  <span className="text-2xl font-bold">${highestMonth.totalAmount.toLocaleString()}</span>
                  <div className="flex items-center mt-2">
                    <Calendar className="h-4 w-4 text-gray-500 mr-1" />
                    <span className="text-sm text-gray-500">
                      {new Date(highestMonth.date).toLocaleDateString("uk-UA", { month: "long" })}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card> */}
          </div>
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
            <BarChart2 size={20} className="text-gray-600" />
            Накопичувальний прогрес
          </h3>

          <div className="mt-8 h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                  width={80}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="amount"
                  stroke="#16a34a"
                  strokeWidth={2}
                  dot={{
                    r: 4,
                    fill: "#16a34a",
                    strokeWidth: 2,
                    stroke: "#fff",
                  }}
                  activeDot={{
                    r: 6,
                    fill: "#16a34a",
                    strokeWidth: 2,
                    stroke: "#fff",
                  }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-10 pt-6 border-t">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium">Щомісячна активність</h3>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-gray-500" />
                <span className="text-sm text-gray-600">
                  Тренд: {isPositiveChange ? "Зростання" : "Спад"}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              {initiativeStatistic
                .slice()
                .reverse()
                .map((item, index, array) => {
                  const prevItem = array[index + 1];
                  const change = prevItem
                    ? item.totalAmount - prevItem.totalAmount
                    : 0;
                  const changePercent = prevItem
                    ? ((change / prevItem.totalAmount) * 100).toFixed(1)
                    : "0";
                  const isPositive = change >= 0;

                  return (
                    <div
                      key={item.date}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium">
                          {new Date(item.date).toLocaleDateString("uk-UA", {
                            month: "long",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <p className="font-medium">
                          ${item.totalAmount.toLocaleString()}
                        </p>
                        {index < array.length - 1 && (
                          <div
                            className={`flex items-center ${
                              isPositive ? "text-green-500" : "text-red-500"
                            }`}
                          >
                            {isPositive ? (
                              <ArrowUp className="h-4 w-4" />
                            ) : (
                              <ArrowDown className="h-4 w-4" />
                            )}
                            <span className="text-sm">
                              {isPositive ? "+" : ""}
                              {changePercent}%
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
