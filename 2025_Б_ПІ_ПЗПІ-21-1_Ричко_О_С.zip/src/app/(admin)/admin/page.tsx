"use client";
import { startTransition, useEffect, useState } from "react";
import { SidebarItem } from "@/components/sidebar-item";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Calendar,
  ClipboardList,
  LogOut,
  Package,
  Target,
  User,
  Users,
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { InputSearch } from "@/components/input-search";
import { AdminInitiativeCardList } from "@/components/admin-initiative-card-list";
import {
  blockFundraising,
  deleteCollection,
  getAllFundraisingsAdmin,
} from "@/app/actions/collections";
import { toast } from "sonner";
import { getAllInitiatives } from "@/app/actions/initiatives";
import { addCategory } from "@/app/actions/categories";
import { getUsersWithSort } from "@/app/actions/user";

type FundraisingCollection = {
  id: number;
  title: string;
  goalAmount: number;
  createdAt: string;
  deadline: string;
  totalCollected: number;
  isBlocked: boolean;
};

export type ImageCollectionItem = {
  id: number;
  title: string;
  description: string;
  imageBase64: string;
};

type UserData = {
  userId: number;
  email: string;
  totalDonated: number;
  donationCount: number;
};

export default function AdminPage() {
  const [activeSection, setActiveSection] = useState("initiatives");
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const [userSortOrder, setUserSortOrder] = useState("");
  const [collection, setCollection] = useState<FundraisingCollection[]>([]);
  const [initiative, setInitiative] = useState<ImageCollectionItem[]>([]);
  const [newCategory, setNewCategory] = useState("");
  const [categoryLoading, setCategoryLoading] = useState(false);
  const [initiativeSearchQuery, setInitiativeSearchQuery] = useState("");
  const [users, setUsers] = useState<UserData[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);

  useEffect(() => {
    startTransition(async () => {
      const collectionFundraise = await getAllFundraisingsAdmin();
      const initiatives = await getAllInitiatives();
      setInitiative(initiatives);
      setCollection(collectionFundraise);
    });
  }, []);

  useEffect(() => {
    if (activeSection !== "users") return;

    setLoadingUsers(true);
    startTransition(async () => {
      const userList = await getUsersWithSort(userSortOrder === "desc");
      setUsers(userList);
      setLoadingUsers(false);
    });
  }, [userSortOrder, activeSection]);

  const handleDelete = async (id: number) => {
    const result = await deleteCollection(id);
    if (result.success) {
      setCollection((prev) => prev.filter((c) => c.id !== id));
      toast.success("Збір успішно видалено");
    } else {
      console.error(result.error);
      toast.error("Не вдалося видалити збір");
    }
  };

  const handleBlockAndUnblock = async (id: number) => {
    const fund = collection.find((item) => item.id === id);
    if (!fund) return;

    const result = await blockFundraising(id, !fund.isBlocked);

    if (result.success) {
      toast.success(fund.isBlocked ? "Збір розблоковано" : "Збір заблоковано");

      const updated = await getAllFundraisingsAdmin();
      setCollection(updated);
    } else {
      toast.error("Не вдалося змінити статус збору");
    }
  };

  const handleAddCategory = async () => {
    if (!newCategory.trim()) return;
    setCategoryLoading(true);
    const success = await addCategory({ categoryName: newCategory.trim() });

    if (success) {
      toast.success("Категорію створено успішно");
      setNewCategory("");
    } else {
      toast.error("Не вдалося створити категорію");
    }

    setCategoryLoading(false);
  };

  const filteredUsers = users.filter((user) => {
    const query = userSearchQuery.toLowerCase();
    return (
      user.email.toLowerCase().includes(query) ||
      user.userId.toString().includes(query)
    );
  });

  return (
    <div className="flex flex-col md:flex-row gap-4 min-h-screen">
      <div className="w-full md:w-[280px] bg-white p-4 rounded-lg shadow-sm flex flex-col">
        <div
          className="flex flex-col items-center gap-3 mb-6 pb-6 border-b cursor-pointer hover:bg-gray-50 rounded-md p-2 transition-colors"
          onClick={() => setActiveSection("profile")}
        >
          <Avatar className="h-20 w-20">
            <AvatarImage src="/placeholder.svg?height=80&width=80" alt="User" />
            <AvatarFallback className="bg-gray-100 text-gray-800">
              <User size={32} />
            </AvatarFallback>
          </Avatar>
          <div className="text-center">
            <h2 className="font-medium text-lg">І'мя користувача</h2>
            <p className="text-sm text-gray-500">Адміністратор</p>
          </div>
        </div>

        <nav className="space-y-1 flex-grow">
          <SidebarItem
            className="whitespace-nowrap"
            icon={<ClipboardList size={18} />}
            label="Адміністрування ініціантив"
            isActive={activeSection === "initiatives"}
            onClick={() => setActiveSection("initiatives")}
          />
          <SidebarItem
            icon={<Package size={18} />}
            label="Збори"
            isActive={activeSection === "collections"}
            onClick={() => setActiveSection("collections")}
          />
          <SidebarItem
            icon={<Users size={18} />}
            label="Користувачі"
            isActive={activeSection === "users"}
            onClick={() => setActiveSection("users")}
          />
        </nav>

        <div className="mt-auto pt-4 border-t">
          <SidebarItem
            icon={<LogOut size={18} />}
            label="Вийти"
            className="text-red-500 hover:bg-red-50"
          />
        </div>
      </div>

      <div className="flex-1 bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-2xl font-semibold mb-6">
          {activeSection === "initiatives" && "Адміністрування ініціантив"}
          {activeSection === "collections" && "Збори"}
          {activeSection === "users" && "Користувачі"}
        </h1>

        <div className="space-y-6">
          {activeSection === "initiatives" && (
            <div className="space-y-6">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="add-category">
                  <AccordionTrigger>Додати категорію</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <Input
                        placeholder="Введіть нову категорію"
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                      />
                      <Button
                        onClick={handleAddCategory}
                        disabled={categoryLoading}
                      >
                        {categoryLoading
                          ? "Створення..."
                          : "Створити нову категорію"}
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>

              <div className="mt-4">
                <InputSearch
                  placeholder="Пошук ініціантив за назвою або описом"
                  searchQuery={initiativeSearchQuery}
                  setSearchQuery={setInitiativeSearchQuery}
                />
              </div>

              <div className="mt-6">
                <h2 className="text-xl font-semibold mb-4">Ініціативи</h2>
                <AdminInitiativeCardList
                  cards={initiative.filter(
                    (item) =>
                      item.title
                        .toLowerCase()
                        .includes(initiativeSearchQuery.toLowerCase()) ||
                      item.description
                        .toLowerCase()
                        .includes(initiativeSearchQuery.toLowerCase())
                  )}
                />
              </div>
            </div>
          )}

          {activeSection === "collections" && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-4">Мої збори</h2>
              <Accordion type="multiple" className="w-full space-y-4">
                {collection.length === 0 ? (
                  <p className="text-gray-500 italic">Немає зборів</p>
                ) : (
                  collection.map((collection) => (
                    <AccordionItem
                      key={collection.id}
                      value={collection.id.toString()}
                      className="border border-gray-200 rounded-lg p-1"
                    >
                      <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 rounded-md">
                        <div className="flex items-center justify-between w-full pr-4">
                          <span className="font-medium">
                            {collection.title}
                          </span>
                          <span className="text-gray-600">
                            Ціль:{" "}
                            <span className="font-medium">
                              {collection.goalAmount.toLocaleString()} ₴
                            </span>
                          </span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-4 py-4">
                        <div className="space-y-4">
                          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex items-center gap-2">
                              <Target className="h-5 w-5 text-gray-500" />
                              <span className="text-gray-700">
                                Ціль:{" "}
                                <span className="font-medium">
                                  {collection.goalAmount.toLocaleString()} ₴
                                </span>
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Calendar className="h-5 w-5 text-gray-500" />
                              <span className="text-gray-700">
                                Дедлайн:{" "}
                                <span className="font-medium">
                                  {new Date(
                                    collection.deadline
                                  ).toLocaleDateString("uk-UA", {
                                    day: "numeric",
                                    month: "long",
                                    year: "numeric",
                                  })}
                                </span>
                              </span>
                            </div>
                          </div>

                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div
                              className="bg-green-600 h-2.5 rounded-full"
                              style={{
                                width: `${Math.min(
                                  100,
                                  (collection.totalCollected /
                                    collection.goalAmount) *
                                    100
                                )}%`,
                              }}
                            ></div>
                          </div>

                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">
                              Зібрано:{" "}
                              {collection.totalCollected.toLocaleString()} ₴
                            </span>
                            <span className="text-gray-600">
                              {Math.round(
                                (collection.totalCollected /
                                  collection.goalAmount) *
                                  100
                              )}
                              %
                            </span>
                          </div>

                          <div className="pt-2">
                            <div className="flex items-center gap-4">
                              <Button
                                variant="outline"
                                className="flex items-center gap-2 text-red-600 border-red-300 hover:bg-red-50"
                                onClick={() => handleDelete(collection.id)}
                              >
                                Видалити
                              </Button>
                              {collection.isBlocked ? (
                                <Button
                                  variant="outline"
                                  className="flex items-center gap-2 text-green-600 border-green-300 hover:bg-green-50"
                                  onClick={() =>
                                    handleBlockAndUnblock(collection.id)
                                  }
                                >
                                  Розблокувати
                                </Button>
                              ) : (
                                <Button
                                  variant="outline"
                                  className="flex items-center gap-2 text-red-600 border-red-300 hover:bg-red-50"
                                  onClick={() =>
                                    handleBlockAndUnblock(collection.id)
                                  }
                                >
                                  Заблокувати
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))
                )}
              </Accordion>
            </div>
          )}

          {activeSection === "users" && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Пошук"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                  />
                </div>
                <div className="w-full sm:w-48">
                  <Select
                    value={userSortOrder}
                    onValueChange={setUserSortOrder}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Сортування" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="asc">за зростанням</SelectItem>
                      <SelectItem value="desc">за спаданням</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4">
                {filteredUsers.map((user) => (
                  <Card key={user.userId}>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="font-medium text-gray-600">
                            Email:
                          </span>
                          <p className="mt-1">{user.email}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-600">ID:</span>
                          <p className="mt-1">{user.userId}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-600">
                            Кількість створених донатів:
                          </span>
                          <p className="mt-1">{user.donationCount}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-600">
                            Загальна сума донатів:
                          </span>
                          <p className="mt-1">
                            {user.totalDonated.toLocaleString()} грн
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
