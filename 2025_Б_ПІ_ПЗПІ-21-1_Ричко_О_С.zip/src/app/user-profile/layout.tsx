import { Header } from "@/components/header";

export default async function UserProfileLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) 
{
    return (
        <section id="user-profile">
            <Header isAuthPage  />
            {children}

        </section>
    );
}