"use client"

import Link from "next/link"
import { startTransition, useActionState, useEffect, useState } from "react"
import { User, Gift, Lightbulb, Bell, Edit3, PlusCircle, LogOut, Package, ExternalLink, BarChart2, Calendar, Target, DollarSign, Clock, Shield, AlertTriangle, X, BellRing, Check } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { useClerk } from "@clerk/nextjs"
import { Input } from "@/components/ui/input"
import { SidebarItem } from "@/components/sidebar-item"
import { InitiativeCardList } from "@/components/initiative-card-list"
import { SubscriptionCardList } from "@/components/subscription-card-list"
import { getMySubscriptions, getUserInitiatives } from "../actions/initiatives"
import { editUserProfile, getUserProfile, getUserSettings, updateUserSettings } from "../actions/user"
import { isTwoFactorAuthenticated, logout, sendTwoFactorCode, verifyCode } from "../actions/auth"
import { getMyDonationHistory } from "../actions/donation"
import TwoFactorAuth from "@/components/two-factor-auth"
import { toast } from "sonner"
import { unsubscribeFromInitiative } from "@/hooks/gavno"
import { Card, CardContent } from "@/components/ui/card"
import { getFundraisingNotes } from "../actions/collections"
import { useRouter } from "next/navigation"
import { useUser } from "@clerk/nextjs"


const collectionsMockData = [
  {
    id: "collection-1",
    name: "Допомога військовим",
    goal: 20000,
    collected: 15000,
    deadline: "2025-06-15",
  },
  {
    id: "collection-2",
    name: "Медичне обладнання",
    goal: 50000,
    collected: 32000,
    deadline: "2025-07-20",
  },
  {
    id: "collection-3",
    name: "Підтримка дітей",
    goal: 15000,
    collected: 9000,
    deadline: "2025-08-10",
  },
]



interface Donation {
  id: number;
  amount: number;
  date: string;
  fundraisingTitle: string;
  fundraisingDeadline: string;
  fundraisingGoal: number;
  initiativeCategoryId: number;
  initiativeTitle: string;
}

type UserData = {
  firstName: string;
  secondName: string;
  email: string;
  avatarFile: File | null;
  imageBase64?: string;
  phoneNumber: string;
};

export type FundraisingNote = {
  id: number
  fundraisingId: number
  createdAt: string 
}


export default function UserProfile() {
  const [isEditing, setIsEditing] = useState(false);
   const { user, isSignedIn, isLoaded } = useUser()
  const { signOut } = useClerk()
  const [donations, setDonations] = useState<Donation[]>([]);
  const [showCodeInput, setShowCodeInput] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");
  const [isTwoFactor, setIsTwoFactor] = useState(false);
  const [initiatives, setInitiatives] = useState([]);
  const [cards, setCards] = useState<any[]>([]);
  const [notification , setNotification] = useState<FundraisingNote[]>([])
  const [mySubscription, setMySubscription] = useState([]);
  const [show2FABanner, setShow2FABanner] = useState(true);
  const [activeSection, setActiveSection] = useState("profile");
   const [notificationSettings, setNotificationSettings] = useState({
    notifyNewFundraising: true,
    notifyNewInitiative: true,
    notifyGoalReached: true,
    frequencyInHours: 24,
  })
  const [isEditingNotifications, setIsEditingNotifications] = useState(false)
  const [isLoadingSettings, setIsLoadingSettings] = useState(false)
  
  const [userData, setUserData] = useState<UserData>({
    firstName: "",
    secondName: "",
    email: "",
    avatarFile: null,
    phoneNumber: "",
    imageBase64: "",
  });

  const [state, formAction, isPending] = useActionState(editUserProfile, null);

  const handleEdit = async () => {
    if (isEditing && !isPending) {
      await handleFormSubmit();
      setIsEditing(false);
    } else {
      setIsEditing(true);
    }
  };

  const handleFormSubmit = async () => {
    const data = new FormData();
    data.append("FirstName", userData.firstName);
    data.append("SecondName", userData.secondName);
    data.append("Email", userData.email);
    data.append("PhoneNumber", userData.phoneNumber);
    if (userData.avatarFile) {
      data.append("AvatarFile", userData.avatarFile);
    }

    try {
      await editUserProfile(data);
    } catch (error) {
      console.error("Failed to update user profile:", error);
    }
  };

  useEffect(() => {
    startTransition(async () => {
      const response = await getUserInitiatives();
      const user = await getUserProfile();
      const myDonations = await getMyDonationHistory();
      const hash2FA = await isTwoFactorAuthenticated();
      const subscription = await getMySubscriptions();
      const note = await getFundraisingNotes()
      const userSettings = await getUserSettings()
      setInitiatives(response);
      setUserData(user);
      setDonations(myDonations);
      setNotification(note)
      setMySubscription(subscription);
     if (userSettings) {
        setNotificationSettings(userSettings)
      }
      const cardData = subscription.map((sub: any) => ({
        id: sub.id,
        initiativeId: sub.initiativeId,
        title: sub.initiative?.title || "Без назви",
        description: sub.initiative?.description || "",
        image: sub.initiative?.imageBase64 || "/placeholder.jpg",
      }));

      setCards(cardData);
      setShow2FABanner(!hash2FA);
      setIsTwoFactor(hash2FA);
    });
  }, []);

  const handleConfirmEmail = async () => {
    setShowCodeInput(true);
    await sendTwoFactorCode();
    toast.success("На вашу електронну пошту було надіслано код перевірки", {
      description: "Код відправлено",
      duration: 4000,
    });
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVerificationCode(e.target.value);
  };

  const handleCodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (verificationCode.trim().length === 6) {
      try {
        await verifyCode(verificationCode);
        const hash2FA = await isTwoFactorAuthenticated();
        setIsTwoFactor(hash2FA);
        setShowCodeInput(false);
        toast.success("Ваша електронна пошта успішно підтверджена", {
          description: "Успішно підтверджено",
          duration: 4000,
        });
        setVerificationCode("");
      } catch (error) {
        toast.error("Код перевірки недійсний або застарілий");
      }
    }
  };

  const handleRemove = async (id: number) => {
    const cardToRemove = cards.find((card) => card.id === id);
    if (!cardToRemove) return;

    setCards((prev) => prev.filter((card) => card.id !== id));
    await unsubscribeFromInitiative(cardToRemove.id);
  };

const handleLogout = async () => {
   await logout()
  try {
     await signOut({ redirectUrl: "/sign-in" })
  } catch (error) {
    console.error("Logout failed:", error)
  }
}

  return (
    <div className="flex flex-col md:flex-row gap-4 p-4 bg-gray-50 min-h-screen">
      <div className="w-full md:w-[280px] bg-white p-4 rounded-lg shadow-sm flex flex-col">
        <div
          className="flex flex-col items-center gap-3 mb-6 pb-6 border-b cursor-pointer hover:bg-gray-50 rounded-md p-2 transition-colors"
          onClick={() => setActiveSection("profile")}
        >
          <Avatar className="h-20 w-20">
            <AvatarImage
              src={userData.avatarFile ? URL.createObjectURL(userData.avatarFile) : userData.imageBase64 || user?.imageUrl ||  ""}
              alt="User"
            />
            <AvatarFallback className="bg-gray-100 text-gray-800">
              <User size={32} />
            </AvatarFallback>
          </Avatar>
          <div className="text-center">
            <h2 className="font-medium text-lg">І'мя користувача</h2>
            <p className="text-sm text-gray-500">{userData.firstName}</p>
          </div>
        </div>

        <nav className="space-y-1 flex-grow">
          <SidebarItem
            icon={<Gift size={18} />}
            label="Мої донати"
            isActive={activeSection === "donations"}
            onClick={() => setActiveSection("donations")}
          />
          <SidebarItem
            icon={<Lightbulb size={18} />}
            label="Мої ініціативи"
            isActive={activeSection === "initiatives"}
            onClick={() => setActiveSection("initiatives")}
          />
          <SidebarItem
            icon={<Package size={18} />}
            label="Мої збори"
            isActive={activeSection === "collections"}
            onClick={() => setActiveSection("collections")}
          />
          <SidebarItem
            icon={<Bell size={18} />}
            label="Підписки"
            isActive={activeSection === "subscriptions"}
            onClick={() => setActiveSection("subscriptions")}
          />
          <SidebarItem
            icon={<BellRing size={18} />}
            label="Сповіщення"
            isActive={activeSection === "notifications"}
            onClick={() => setActiveSection("notifications")}
          />
        </nav>

        <div className="mt-auto pt-4 border-t">
          <SidebarItem icon={<LogOut size={18} />} label="Вийти" onClick={handleLogout} className="text-red-500 hover:bg-red-50" />
        </div>
      </div>

      <div className="flex-1 bg-white p-6 rounded-lg shadow-sm">
        {show2FABanner && (
          <div className="mb-6 bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start justify-between">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-amber-800">Підвищте безпеку свого акаунту</h3>
                <p className="text-sm text-amber-700 mt-1">
                  Рекомендуємо пройти двофакторну автентифікацію для захисту вашого акаунту. Перейдіть до розділу
                  "Особисті дані" → "Двофакторна автентифікація".
                </p>
              </div>
            </div>
            <button
              onClick={() => setShow2FABanner(false)}
              className="text-amber-600 hover:text-amber-800 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}



        <h1 className="text-2xl font-semibold mb-6">
          {activeSection === "profile" && "Особисті дані"}
          {activeSection === "donations" && "Мої донати"}
          {activeSection === "initiatives" && "Мої ініціативи"}
          {activeSection === "collections" && "Мої збори"}
          {activeSection === "subscriptions" && "Підписки"}
          {activeSection === "notifications" && "Сповіщення"}
        </h1>
        <div className="space-y-6">
          {activeSection === "profile" && (
            <Accordion type="single" collapsible defaultValue="account" className="w-full space-y-4">
              <AccordionItem value="account" className="border border-gray-200 rounded-lg p-1 shadow-sm">
                <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-md">
                  <div className="flex items-center gap-3">
                    <User className="h-5 w-5 text-gray-600" />
                    <span>Мій акаунт</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 py-3">
                  {isEditing ? (
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Ім’я</label>
                        <Input
                          value={userData.firstName}
                          onChange={(e) => setUserData({ ...userData, firstName: e.target.value })}
                          className="max-w-md"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Прізвище</label>
                        <Input
                          value={userData.secondName}
                          onChange={(e) => setUserData({ ...userData, secondName: e.target.value })}
                          className="max-w-md"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Електронна пошта</label>
                        <Input
                          type="email"
                          value={userData.email}
                          onChange={(e) => setUserData({ ...userData, email: e.target.value })}
                          className="max-w-md"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Телефон</label>
                        <Input
                          value={userData.phoneNumber}
                          onChange={(e) => setUserData({ ...userData, phoneNumber: e.target.value })}
                          className="max-w-md"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Аватар</label>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) => setUserData({ ...userData, avatarFile: e.target.files?.[0] || null })}
                          className="max-w-md"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="font-medium">{`${userData.firstName} ${userData.secondName}`}</p>
                      <p className="text-gray-600">{userData.email}</p>
                      <p className="text-gray-600">{userData.phoneNumber}</p>
                    </div>
                  )}

                  <Button onClick={handleEdit} variant="outline" className="mt-4 flex items-center gap-2">
                    {isEditing ? "Зберегти" : "Редагувати"}
                    <Edit3 size={16} />
                  </Button>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="security" className="border border-gray-200 rounded-lg p-1 shadow-sm">
                <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-md">
                  <div className="flex items-center gap-3">
                    <Shield className="h-5 w-5 text-gray-600" />
                    <span>Двофакторна автентифікація</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 py-3">
                  <TwoFactorAuth
                    isTwoFactor={isTwoFactor}
                    showCodeInput={showCodeInput}
                    handleConfirmEmail={handleConfirmEmail}
                    handleCodeChange={handleCodeChange}
                    verificationCode={verificationCode}
                    handleCodeSubmit={handleCodeSubmit}
                    setShowCodeInput={setShowCodeInput}
                  />
                </AccordionContent>
              </AccordionItem>
                <AccordionItem value="notifications" className="border border-gray-200 rounded-lg p-1 shadow-sm">
                <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-md">
                  <div className="flex items-center gap-3">
                    <BellRing className="h-5 w-5 text-gray-600" />
                    <span>Налаштування сповіщень</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 py-3">
                  {isEditingNotifications ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id="notifyNewFundraising"
                          checked={notificationSettings.notifyNewFundraising}
                          onChange={(e) =>
                            setNotificationSettings({
                              ...notificationSettings,
                              notifyNewFundraising: e.target.checked,
                            })
                          }
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="notifyNewFundraising" className="text-sm text-gray-700">
                          Сповіщати про нові збори
                        </label>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id="notifyNewInitiative"
                          checked={notificationSettings.notifyNewInitiative}
                          onChange={(e) =>
                            setNotificationSettings({
                              ...notificationSettings,
                              notifyNewInitiative: e.target.checked,
                            })
                          }
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="notifyNewInitiative" className="text-sm text-gray-700">
                          Сповіщати про нові ініціативи
                        </label>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id="notifyGoalReached"
                          checked={notificationSettings.notifyGoalReached}
                          onChange={(e) =>
                            setNotificationSettings({
                              ...notificationSettings,
                              notifyGoalReached: e.target.checked,
                            })
                          }
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="notifyGoalReached" className="text-sm text-gray-700">
                          Сповіщати про досягнення цілей
                        </label>
                      </div>

                      <div className="mt-4">
                        <label htmlFor="frequencyInHours" className="block text-sm text-gray-500 mb-1">
                          Частота сповіщень (годин)
                        </label>
                        <Input
                          id="frequencyInHours"
                          type="number"
                          value={notificationSettings.frequencyInHours}
                          onChange={(e) =>
                            setNotificationSettings({
                              ...notificationSettings,
                              frequencyInHours: Number.parseInt(e.target.value),
                            })
                          }
                          className="max-w-[100px]"
                          min="1"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-sm text-gray-700">
                        <span className="font-medium">Сповіщати про нові збори:</span>{" "}
                        {notificationSettings.notifyNewFundraising ? "Так" : "Ні"}
                      </p>
                      <p className="text-sm text-gray-700">
                        <span className="font-medium">Сповіщати про нові ініціативи:</span>{" "}
                        {notificationSettings.notifyNewInitiative ? "Так" : "Ні"}
                      </p>
                      <p className="text-sm text-gray-700">
                        <span className="font-medium">Сповіщати про досягнення цілей:</span>{" "}
                        {notificationSettings.notifyGoalReached ? "Так" : "Ні"}
                      </p>
                      <p className="text-sm text-gray-700">
                        <span className="font-medium">Частота сповіщень:</span> кожні{" "}
                        {notificationSettings.frequencyInHours} годин
                      </p>
                    </div>
                  )}

                  <Button
                    onClick={async () => {
                      if (isEditingNotifications) {
                        setIsLoadingSettings(true)
                        try {
                          const success = await updateUserSettings(notificationSettings)
                          if (success) {
                            toast.success("Налаштування сповіщень збережено")
                            setIsEditingNotifications(false)
                          } else {
                            toast.error("Помилка при збереженні налаштувань")
                          }
                        } catch (error) {
                          toast.error("Помилка при збереженні налаштувань")
                          console.error("Error updating settings:", error)
                        } finally {
                          setIsLoadingSettings(false)
                        }
                      } else {
                        setIsEditingNotifications(true)
                      }
                    }}
                    variant="outline"
                    className="mt-4 flex items-center gap-2"
                    disabled={isLoadingSettings}
                  >
                    {isEditingNotifications ? (isLoadingSettings ? "Збереження..." : "Зберегти") : "Редагувати"}
                    {isEditingNotifications ? isLoadingSettings ? null : <Check size={16} /> : <Edit3 size={16} />}
                  </Button>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          )}

          {activeSection === "donations" && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-4">Історія донатів</h2>

              {donations.length === 0 ? (
                <p className="text-gray-500">У вас поки що немає донатів</p>
              ) : (
                <Accordion type="multiple" className="w-full space-y-4">
                  {donations.map((donation) => (
                    <AccordionItem
                      key={donation.id}
                      value={donation.id.toString()}
                      className="border border-gray-200 rounded-lg p-1"
                    >
                      <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 rounded-md">
                        <div className="flex items-center justify-between w-full pr-4">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{donation.fundraisingTitle}</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="text-gray-600">
                              Донат: <span className="font-medium">{donation.amount.toLocaleString()} ₴</span>
                            </span>
                            <span className="text-gray-600 text-sm">
                              {new Date(donation.date).toLocaleDateString("uk-UA", {
                                day: "numeric",
                                month: "short",
                              })}
                            </span>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-4 py-4">
                        <div className="space-y-4">
                          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex items-center gap-2">
                              <Target className="h-5 w-5 text-gray-500" />
                              <span className="text-gray-700">
                                Назва збору: <span className="font-medium">{donation.fundraisingTitle}</span>
                              </span>
                            </div>
                          </div>

                          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                            <div className="flex items-center gap-2">
                              <DollarSign className="h-5 w-5 text-gray-500" />
                              <span className="text-gray-700">
                                Донат: <span className="font-medium">{donation.amount.toLocaleString()} ₴</span>
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <Clock className="h-5 w-5 text-gray-500" />
                              <span className="text-gray-700">
                                Дата:{" "}
                                <span className="font-medium">
                                  {new Date(donation.date).toLocaleDateString("uk-UA", {
                                    day: "numeric",
                                    month: "long",
                                    year: "numeric",
                                  })}
                                </span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </div>
          )}


          {activeSection === "initiatives" && (
            <div className="space-y-6">
              <Accordion type="single" collapsible defaultValue="create" className="w-full">
                <AccordionItem value="create" className="border border-gray-200 rounded-lg p-1">
                  <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-md">
                    <div className="flex items-center gap-3">
                      <Lightbulb className="h-5 w-5 text-gray-600" />
                      <span>Створити інціативу</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 py-3">
                    <Button className="flex items-center gap-2 w-26" asChild>
                      <Link href="/create-initiative">
                        <PlusCircle size={16} />
                        Створити
                      </Link>
                    </Button>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>

              <div className="mt-6">
                <h2 className="text-xl font-semibold mb-4">Мої ініціативи</h2>
                <InitiativeCardList cards={initiatives} />
              </div>
            </div>
          )}

          {activeSection === "collections" && (
            <div className="space-y-6">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-amber-800">
                    Для отримання зібраних грошей зі створених ініціатив та зборів, будь-ласка, зв'яжитесь із підтримкою{" "}
                    <a href="mailto:support@example.com" className="font-medium underline hover:no-underline">
                      support@example.com
                    </a>
                    . Наша підтримка уточнить реквізити платежу і ваш запит буде оброблено якнайшвидше.
                  </p>
                </div>
              </div>
              <h2 className="text-xl font-semibold mb-4">Мої збори</h2>
              <Accordion type="multiple" className="w-full space-y-4">
                {collectionsMockData.map((collection) => (
                  <AccordionItem
                    key={collection.id}
                    value={collection.id}
                    className="border border-gray-200 rounded-lg p-1"
                  >
                    <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 rounded-md">
                      <div className="flex items-center justify-between w-full pr-4">
                        <span className="font-medium">{collection.name}</span>
                        <span className="text-gray-600">
                          Ціль: <span className="font-medium">{collection.goal.toLocaleString()} ₴</span>
                        </span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 py-4">
                      <div className="space-y-4">
                        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                          <div className="flex items-center gap-2">
                            <Target className="h-5 w-5 text-gray-500" />
                            <span className="text-gray-700">
                              Ціль: <span className="font-medium">{collection.goal.toLocaleString()} ₴</span>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <Calendar className="h-5 w-5 text-gray-500" />
                            <span className="text-gray-700">
                              Дедлайн:{" "}
                              <span className="font-medium">
                                {new Date(collection.deadline).toLocaleDateString("uk-UA", {
                                  day: "numeric",
                                  month: "long",
                                  year: "numeric",
                                })}
                              </span>
                            </span>
                          </div>
                        </div>

                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div
                            className="bg-green-600 h-2.5 rounded-full"
                            style={{ width: `${Math.min(100, (collection.collected / collection.goal) * 100)}%` }}
                          ></div>
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Зібрано: {collection.collected.toLocaleString()} ₴</span>
                          <span className="text-gray-600">
                            {Math.round((collection.collected / collection.goal) * 100)}%
                          </span>
                        </div>

                        <div className="pt-2">
                          <Button variant="outline" className="flex items-center gap-2" asChild>
                            <Link href={`/collection-statistic/${collection.id}`}>
                              <BarChart2 size={16} />
                              <span>Статистика</span>
                              <ExternalLink size={14} className="ml-1" />
                            </Link>
                          </Button>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          )}

          {activeSection === "subscriptions" && (
            <div>
              <h2 className="text-xl font-semibold mb-4">Підписки</h2>
              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-8">
                  <div>
                    <span className="text-gray-600 font-medium">Кількість:</span>
                    <span className="ml-2">{cards.length}</span>
                  </div>
                  <div>
                    <span className="text-gray-600 font-medium">Пошта:</span>
                    <span className="ml-2">{userData.email}</span>
                  </div>
                </div>
              </div>

              <SubscriptionCardList cards={cards} onRemove={handleRemove} />
            </div>
          )}
          {activeSection === "notifications" && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-4">Сповіщення</h2>
              <div className="space-y-4">
                {notification.length === 0 ? (
                  <p className="text-gray-500">У вас поки що немає сповіщень</p>
                ) : (
                  notification.map((notification) => (
                    <Card key={notification.id} className="border border-gray-200 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="bg-blue-50 p-2 rounded-full">
                            <BellRing className="h-5 w-5 text-blue-500" />
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start">
                              <h3 className="font-medium">Оновлення збору #{notification.fundraisingId}</h3>
                              <span className="text-xs text-gray-500">
                                {new Date(notification.createdAt).toLocaleDateString("uk-UA", {
                                  day: "numeric",
                                  month: "short",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">
                              Збір #{notification.fundraisingId} було оновлено. Перевірте деталі.
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}