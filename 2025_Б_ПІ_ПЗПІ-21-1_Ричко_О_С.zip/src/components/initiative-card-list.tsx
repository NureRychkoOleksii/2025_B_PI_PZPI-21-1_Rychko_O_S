"use client";
import { useState } from "react";
import { Card } from "./card-base";
import { deleteInitiative } from "@/app/actions/initiatives";
import { useRouter } from "next/navigation";




type Initiative = {
  id: number;
  imageBase64: string;
  title: string;
  description: string;
};


export const InitiativeCardList = ({ cards }: { cards: Initiative[] }) => {
  const [initiatives, setInitiatives] = useState(cards)
  const router = useRouter();
  
    const handleEdit = (id: number) => {
      router.push(`/edit-initiative/${id}`)
  }

  const handleStats = (id: number) => {
     router.push(`/initiative-statistic/${id}`)
  }

  const handleDelete = async (id: number) => {
    setInitiatives(initiatives.filter((initiative) => initiative.id !== id))
    await deleteInitiative(id)
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {initiatives.map((initiative) => (
        <Card
          id={initiative.id}  
          key={initiative.id}
          image={initiative.imageBase64}
          title={initiative.title}
          description={initiative.description}
          useEllipsisMenu={true}
          onEdit={() => handleEdit(initiative.id)}
          onStats={() => handleStats(initiative.id)}
          onDelete={() => handleDelete(initiative.id)} 
        />
      ))}
    </div>
  )
}