"use client";

import { CategoryFilter } from "./category-filter";
import { Category } from "@/app/actions/categories";

export const Sidebar = ({
  categories,
  onApplyFilter,
  selectedCategories
}: {
  categories: Category[];
  onApplyFilter: (selected: string[]) => void;
  selectedCategories: string[];
}) => {
  return (
    <aside className="bg-white border border-gray-200 p-4 rounded">
      <h1 className="text-lg font-semibold text-gray-800 mb-4">Initiatives</h1>
      <CategoryFilter
        categories={categories}
        onApplyFilter={onApplyFilter}
        initialSelected={selectedCategories}
      />
    </aside>
  );
};
