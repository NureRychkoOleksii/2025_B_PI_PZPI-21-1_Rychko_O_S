"use client";
import { Dialog , DialogContent , DialogHeader , DialogDescription,DialogTitle, DialogFooter } from "./ui/dialog";
import { BarChart2, Edit3, MoreVertical, Trash, X } from "lucide-react";
import Image from "next/legacy/image";
import { useState } from "react";
import { Button } from "./ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { useRouter } from "next/navigation"
import Link from "next/link";


type CardProps = {
  id: number
  image: string
  title: string
  description: string
  onRemove?: () => void
  useEllipsisMenu?: boolean
  onEdit?: () => void
  onStats?: () => void
  onDelete?: () => void
}

export const Card = ({
  id,
  image,
  title,
  description,
  onRemove,
  useEllipsisMenu = false,
  onEdit,
  onStats,
  onDelete,
}: CardProps) => {
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const router = useRouter()

  const handleRemoveClick = () => {
    setShowConfirmDialog(true)
  }

  const handleConfirm = () => {
    if (onRemove) {
      onRemove()
    }
    setShowConfirmDialog(false)
  }

   const handleCardClick = () => {
    router.push(`/initiative/${id}`)
  }


  const handleDelete = () => {
    setShowConfirmDialog(true)
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden w-full max-w-sm relative group cursor-pointer">
      {!useEllipsisMenu && onRemove && (
        <button
          onClick={handleRemoveClick}
          className="absolute top-2 right-2 z-10 bg-white rounded-full p-1 shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
          aria-label="Remove"
        >
          <X size={16} className="text-gray-600 hover:text-red-500" />
        </button>
      )}

      {useEllipsisMenu && (
        <div className="absolute top-2 right-2 z-10">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                className="bg-white rounded-full p-1 shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Options"
              >
                <MoreVertical size={16} className="text-gray-600" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit} className="cursor-pointer">
                <Link className="flex items-end" href={`/edit-initiative/${id}`}>
                  <Edit3 className="mr-4 h-4 w-4" />
                  <span>Редагувати</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onStats} className="cursor-pointer">
                <BarChart2 className="mr-2 h-4 w-4" />
                <span>Статистика</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDelete} className="cursor-pointer text-red-500 focus:text-red-500">
                <Trash className="mr-2 h-4 w-4" />
                <span>Видалити</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      <div className="relative w-full h-40"
        onClick={handleCardClick}>
          <img src={`data:image/jpeg;base64,${image}`} alt="base64 image"  className="object-cover w-full h-full"/>
      </div>
      <div className="p-4 space-y-2">
        <h2 className="text-lg font-semibold text-gray-800">{title}</h2>
        <p className="text-sm text-gray-600">{description}</p>
      </div>

      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Підтвердження</DialogTitle>
            <DialogDescription>
              {useEllipsisMenu
                ? "Ви впевненні що хочете видалити цю ініціативу?"
                : "Ви впевненні що хочете відписатися?"}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex justify-end gap-2 sm:justify-end">
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Ні
            </Button>
            <Button variant="destructive" onClick={useEllipsisMenu ? onDelete || (() => {}) : handleConfirm}>
              Так
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}




type Initiative = {
  id: number;
  imageBase64: string;
  title: string;
  description: string;
};

type CardListProps = {
  showRemove?: boolean;
  initiatives?: Initiative[];
};

export const CardList = ({ showRemove = false, initiatives = [] }: CardListProps) => {
  const [internalCards, setInternalCards] = useState(initiatives);
  console.log("CardList initiatives:", internalCards);
  const cards = initiatives || internalCards;
  const router = useRouter();

  const handleRemove = (id: number) => {
    setInternalCards(internalCards.filter((card) => card.id !== id));
  };

   const handleEdit = (id: number) => {
    router.push(`/edit-initiative/${id}`);
  };
  

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {cards.map((card) => (
        <Card
          key={card.id}
          id={card.id}
          image={card.imageBase64}
          title={card.title}
          description={card.description}
          onRemove={showRemove ? () => handleRemove(card.id) : undefined}
          onEdit={() => handleEdit(card.id)}
        />
      ))}
    </div>
  );
};


