"use client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { Calendar, Target, Ban, CheckCircle } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog"
import { Input } from "./ui/input"

interface CollectionCardProps {
  id: string
  title: string
  goal: number
  collected: number
  deadline: string
  description: string
  isBlocked: boolean
  isAuthenticated?: boolean
  handleDonationModelOpen: () => void
  showDonationModal: boolean
  setShowDonationModal: React.Dispatch<React.SetStateAction<boolean>>
  donationAmount: string
  setDonationAmount: React.Dispatch<React.SetStateAction<string>>
  handleDonationConfirm: (e: React.FormEvent, id: number) => Promise<void>
}

export function CollectionCard({
  id,
  title,
  goal,
  collected,
  deadline,
  isBlocked,
  description,
  isAuthenticated,
  handleDonationModelOpen,
  showDonationModal,
  setShowDonationModal,
  donationAmount,
  setDonationAmount,
  handleDonationConfirm,
}: CollectionCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const progress = Math.min(100, Math.round((collected / goal) * 100))

  return (
    <Card
      className="overflow-hidden transition-shadow hover:shadow-md"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">{title}</CardTitle>
          <div className="flex items-center gap-2 text-sm font-medium">
            {isBlocked ? (
              <div className="flex items-center gap-1 text-red-600">
                <Ban className="w-4 h-4" />
                <span>Заблокований</span>
              </div>
            ) : (
              <div className="flex items-center gap-1 text-green-600">
                <CheckCircle className="w-4 h-4" />
                <span>Доступний</span>
              </div>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-gray-500" />
            <span className="text-gray-700">
              Ціль: <span className="font-medium">{goal.toLocaleString()} ₴</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-gray-500" />
            <span className="text-gray-700">
              Дедлайн:{" "}
              <span className="font-medium">
                {new Date(deadline).toLocaleDateString("uk-UA", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </span>
            </span>
          </div>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-green-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
        </div>

        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Зібрано: {collected.toLocaleString()} ₴</span>
          <span className="text-gray-600">{progress}%</span>
        </div>

        <p className="text-sm text-gray-600">{description}</p>


        <Dialog open={showDonationModal} onOpenChange={setShowDonationModal}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Донат</DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => handleDonationConfirm(e, Number(id))} className="space-y-4">
              <div className="space-y-2">
                <Input
                  type="number"
                  placeholder="Введіть сумму донату"
                  value={donationAmount}
                  onChange={(e) => setDonationAmount(e.target.value)}
                  required
                  min="1"
                  step="0.01"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowDonationModal(false)
                    setDonationAmount("")
                  }}
                >
                  Скасувати
                </Button>
                <Button type="submit">Підвердити донат</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Action Buttons */}
        <div className="pt-2 flex flex-wrap gap-2">
          {!isBlocked ? (
            <Button className="flex-1" onClick={handleDonationModelOpen}>Підтримати</Button>
          ) : null}
          <Button variant="outline" className="flex items-center gap-2" asChild>
            <Link href={isAuthenticated ? `/collection-statistic/${id}` : "/sign-in"}>
              <span>Деталі</span>
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
