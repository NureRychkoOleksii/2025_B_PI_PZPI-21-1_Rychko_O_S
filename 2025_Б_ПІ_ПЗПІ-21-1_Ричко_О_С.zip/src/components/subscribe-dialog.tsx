"use client"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface SubscribeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  isSubscribed: boolean
  onConfirm: () => void
}

export function SubscribeDialog({ open, onOpenChange, isSubscribed, onConfirm }: SubscribeDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Підтвердження</DialogTitle>
          <DialogDescription>
            {isSubscribed
              ? "Ви впевнені що хочете відписатися від цієї ініціативи?"
              : "Ви впевнені що хочете підписатися на цю ініціативу?"}
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex justify-end gap-2 sm:justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Ні
          </Button>
          <Button variant={isSubscribed ? "destructive" : "default"} onClick={onConfirm}>
            Так
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
