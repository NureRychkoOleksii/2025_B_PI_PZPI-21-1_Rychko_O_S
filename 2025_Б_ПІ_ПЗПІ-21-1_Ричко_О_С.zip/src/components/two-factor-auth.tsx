"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail, CheckCircle } from "lucide-react"

interface TwoFactorAuthProps {
  isTwoFactor: boolean
  showCodeInput: boolean
  handleConfirmEmail: () => void
  handleCodeChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  verificationCode: string
  handleCodeSubmit: (e: React.FormEvent) => void
  setShowCodeInput: (value: boolean) => void
}

export default function TwoFactorAuth({
  isTwoFactor,
  showCodeInput,
  handleConfirmEmail,
  handleCodeChange,
  verificationCode,
  handleCodeSubmit,
  setShowCodeInput
}: TwoFactorAuthProps) {

  return (
    <div className="space-y-4">
      {isTwoFactor ? (
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-green-600">
            <CheckCircle className="h-5 w-5" />
            <span className="font-medium">2FA активована</span>
          </div>
          <p className="text-sm text-gray-600">
            Ваш акаунт захищено двофакторною автентифікацією
          </p>
        </div>
      ) : !showCodeInput ? (
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Mail className="h-5 w-5 text-gray-400" />
            <span className="text-sm text-gray-600">2FA не активована</span>
          </div>
          <p className="text-sm text-gray-600">
            Пройдіть двофакторну автентифікацію для захисту свого акаунту
          </p>
          <Button onClick={handleConfirmEmail} variant="outline">
            Підтвердити пошту
          </Button>
        </div>
      ) : (
        <form onSubmit={handleCodeSubmit} className="space-y-4">
          <p className="text-sm text-gray-600">
            Введіть код, який було надіслано на вашу електронну пошту
          </p>
          <Input
            type="text"
            placeholder="Введіть код перевірки"
            value={verificationCode}
            onChange={handleCodeChange}
            className="text-center font-mono tracking-widest max-w-md"
            maxLength={6}
            autoFocus
          />
          <div className="flex space-x-2">
            <Button
              type="submit"
              className="bg-green-600 hover:bg-green-700"
              disabled={verificationCode.length < 6}
            >
              Підтвердити код
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowCodeInput(false)}
            >
              Скасувати
            </Button>
          </div>
        </form>
      )}
    </div>
  )
}
